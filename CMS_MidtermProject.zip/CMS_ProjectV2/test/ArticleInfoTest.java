import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArticleInfoTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getID() {
    }

    @Test
    void getIDString() {
    }

    @Test
    void getTitle() {
    }

    @Test
    void getAFirst() {
    }

    @Test
    void getALast() {
    }

    @Test
    void getPhoto() {
    }

    @Test
    void getHeadings() {
    }

    @Test
    void getParagraphs() {
    }

    @Test
    void getBrowserAddress() {
    }

    @Test
    void getPostAt() {
    }

    @Test
    void setPostAt() {
    }

    @Test
    void getStatus() {
    }

    @Test
    void setStatus() {
    }

    @Test
    void searchBy() {
    }

    @Test
    void byID() {
    }

    @Test
    void byTitle() {
    }

    @Test
    void byAuthor() {
    }

    @Test
    void fileOutput() {
    }

    @Test
    void publisher() {
    }
}